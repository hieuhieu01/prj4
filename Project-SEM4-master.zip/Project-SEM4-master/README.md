Xampp : thêm "max_allowed_packet=200M"

Thêm các role trong phpmyadmin

Sau đó thêm tài khoản admin và user

Để  thêm 1 bài hát cần thêm data cho tác giả, album, thể loại, ca sĩ

Chạy code trên Intelij IDEA.
