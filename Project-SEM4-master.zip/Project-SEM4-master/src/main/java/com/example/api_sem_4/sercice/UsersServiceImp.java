package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.SongEntity;
import com.example.api_sem_4.entity.UserEntity;
import com.example.api_sem_4.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class UsersServiceImp implements UsersService {
    @Autowired
    UserRepo userRepo;

    @Override
    public List<UserEntity> getUser() {
        return userRepo.findAll();
    }

    @Override
    public Optional<UserEntity> findUsersById(int id) {
        return userRepo.findById(id);
    }

    @Override
    public UserEntity createUser(MultipartFile file, UserEntity userEntity) throws IOException {
        return userRepo.save(userEntity);
    }

    @Override
    public UserEntity getId(int id) {
        return userRepo.getById(id);
    }
    @Override
    public Stream<UserEntity> getAllImage() {
        return userRepo.findAll().stream();
    }

    @Override
    public void updateAvatar(MultipartFile file, Integer id) throws IOException {
        userRepo.updateAvatar(file.getBytes(),id);
    }

    @Override
    public void updateProfile(String username, String dateofbirth, String address, String phone, String email, Integer id) {
        userRepo.updateProfile(username, dateofbirth, address, phone, email, id);
    }

    @Override
    public Long getCount() {
        return userRepo.getCount();
    }

//    @Override
//    public Page<UserEntity> getSongByName(String name, Pageable pageable) {
//        return userRepo.findSongByName(name,pageable);
//    }


}
