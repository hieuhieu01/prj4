package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.AuthorEntity;
import com.example.api_sem_4.entity.GenreEntity;
import com.example.api_sem_4.sercice.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class AuthorController {
    @Autowired
    AuthorService authorService;

    @ModelAttribute("list_author")
    public List<AuthorEntity> list() {
        return authorService.getAuthor();
    }

    @GetMapping("/table-author")
    public String getAllAuthor(Model model, @RequestParam("name") Optional<String> name, @RequestParam(value = "page", defaultValue = "0") int page, @RequestParam(value = "size", defaultValue = "5") int size) {
        AuthorEntity authorEntity = new AuthorEntity();
        model.addAttribute("authors",authorEntity);

        List<AuthorEntity> authorlist;
        int totalPage;
        if (name.isPresent()) {
            authorlist = authorService.getByName(name.get(), PageRequest.of(page, size));
            totalPage  = authorService.getTotalPageSearch(name.get(),PageRequest.of(page, size));
            model.addAttribute("t",1);
            model.addAttribute("namesearch",name.get());
        } else {
            authorlist = authorService.getAllAuthor(PageRequest.of(page, size));
            totalPage  = authorService.getTotalPage(PageRequest.of(page, size));
        }
        model.addAttribute("totalPage", totalPage);
        model.addAttribute("size", size);
        model.addAttribute("page", page);
        model.addAttribute("authorlist",authorlist);

        return "admin/table-author";
    }

    @PostMapping("/table-author")
    public String upload(Model model, AuthorEntity authorEntity){
        authorService.createAuthor(authorEntity);
        return "redirect:/table-author";
    }

    @GetMapping("/delete-author/{id}")
    public String deleteAuthor(Model model, @PathVariable int id) {
        if (id != 0) {
            authorService.deleteAuthor(id);
        }
        return "redirect:/table-author";
    }

    @GetMapping("/update-author/{id}")
    public String updateAuthor(Model model,@PathVariable int id) {
        AuthorEntity authorEntity = authorService.getId(id);
        model.addAttribute("authors", authorEntity);
        return "admin/update-author";
    }

    @PostMapping("/update-author")
    public String updateAuthor(Model model, AuthorEntity authorEntity){
        authorService.updateAuthor(authorEntity);
        return "redirect:/table-author";
    }
}
