package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.MvEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface MvService {
    List<MvEntity> getMv();
    Optional<MvEntity> findMvById(int id);
    Page<MvEntity> getMvByName(String name, Pageable pageable);
    MvEntity createMv(MultipartFile url,MultipartFile file, MvEntity mvEntity) throws IOException;

    Page<MvEntity> findAll(Pageable pageable);

    List<MvEntity> getAllMv(Pageable pageable);
    int getTotalPage(Pageable pageable);
    void deleteMv(int id);

    MvEntity getId(int id);
    MvEntity updateMv(MultipartFile url,MultipartFile file,MvEntity mvEntity) throws IOException;
    List<MvEntity> getByName(String name, Pageable pageable);
    int getTotalPageSearch(String name, Pageable pageable);
    Stream<MvEntity> getAllImage();

    Stream<MvEntity> getAllUrl();
    Long getCount();
}
