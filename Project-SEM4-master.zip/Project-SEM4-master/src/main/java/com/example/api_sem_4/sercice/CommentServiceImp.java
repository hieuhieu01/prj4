package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.CommentEntity;
import com.example.api_sem_4.repository.CommentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CommentServiceImp implements CommentService {
    @Autowired
    CommentRepo commentRepo;

    @Override
    public Optional<CommentEntity> findCommentById(int id) {
        return commentRepo.findById(id);
    }

    @Override
    public CommentEntity createComment(CommentEntity commentEntity) {
        return commentRepo.save(commentEntity);
    }

    @Override
    public Long getCount() {
        return commentRepo.getCount();
    }

}
