package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.AuthorEntity;
import com.example.api_sem_4.repository.AuthorRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorServiceImp implements AuthorService {
    @Autowired
    AuthorRepo authorRepo;

    @Override
    public List<AuthorEntity> getAuthor() {
        return authorRepo.findAll();
    }

    @Override
    public AuthorEntity createAuthor(AuthorEntity authorEntity) {
        return authorRepo.save(authorEntity);
    }

    @Override
    public void deleteAuthor(int id) {
        authorRepo.deleteById(id);
    }

    @Override
    public int getTotalPage(Pageable pageable) {
        return authorRepo.findAll(pageable).getTotalPages();
    }

    @Override
    public List<AuthorEntity> getAllAuthor(Pageable pageable) {
        return authorRepo.findAll(pageable).getContent();
    }

    @Override
    public AuthorEntity getId(int id) {
        return authorRepo.getById(id);
    }

    @Override
    public AuthorEntity updateAuthor(AuthorEntity authorEntity) {
        return authorRepo.save(authorEntity);
    }

    @Override
    public List<AuthorEntity> getByName(String name, Pageable pageable) {
        return authorRepo.findByName(name,pageable);
    }

    @Override
    public int getTotalPageSearch(String name, Pageable pageable) {
        return authorRepo.findAuthorByName(name,pageable).getTotalPages();
    }

    @Override
    public Long getCount() {
        return authorRepo.getCount();
    }
}
