package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.AuthorEntity;
import com.example.api_sem_4.entity.GenreEntity;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AuthorService {
    List<AuthorEntity> getAuthor();
    AuthorEntity createAuthor(AuthorEntity authorEntity);

    void deleteAuthor(int id);
    int getTotalPage(Pageable pageable);
    List<AuthorEntity> getAllAuthor(Pageable pageable);

    AuthorEntity getId(int id);
    AuthorEntity updateAuthor(AuthorEntity authorEntity);
    List<AuthorEntity> getByName(String name, Pageable pageable);
    int getTotalPageSearch(String name, Pageable pageable);

    Long getCount();
}
