package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.PlaylistEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface PlaylistService {
    Stream<PlaylistEntity> getAllImage();

    PlaylistEntity store(MultipartFile file, PlaylistEntity playlistEntity) throws IOException;

    PlaylistEntity getFile(int id);

    List<PlaylistEntity> getPlaylist();
    PlaylistEntity createPlayList(PlaylistEntity playlistEntity);

    Optional<PlaylistEntity> findPlaylistById(int id);
//
    void remove(int id);
    PlaylistEntity getId(int id);
    PlaylistEntity update(MultipartFile file, PlaylistEntity playlistEntity) throws IOException;
}
