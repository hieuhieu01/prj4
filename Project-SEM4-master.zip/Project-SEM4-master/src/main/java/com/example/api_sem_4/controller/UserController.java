package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.PlaylistEntity;
import com.example.api_sem_4.entity.SongEntity;
import com.example.api_sem_4.entity.UserEntity;
import com.example.api_sem_4.sercice.UserService;
import com.example.api_sem_4.sercice.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

@Controller
public class UserController {
    @Autowired
    UsersService usersService;

    @Autowired
    UserService userService;

    @GetMapping("/user")
    public String getProfile(Model model, Principal principal) {
        String username = principal.getName();
        UserDetails user=userService.loadUserByUsername(username);
        model.addAttribute("user",user);
        return "main/profile";
    }

    @PostMapping("/update-user")
    public String updateUser(Model model, UserEntity userEntity){
        usersService.updateProfile(userEntity.getUsername(), userEntity.getDateofbirth(), userEntity.getAddress(), userEntity.getPhone(), userEntity.getEmail(), userEntity.getId());
        return "redirect:/user";
    }

    @PostMapping("/update-user-avatar")
    public String updateUser(@RequestParam("avataruser") MultipartFile file, Model model, UserEntity userEntity) throws IOException {
        usersService.updateAvatar(file, userEntity.getId());
        return "redirect:/user";
    }

}
