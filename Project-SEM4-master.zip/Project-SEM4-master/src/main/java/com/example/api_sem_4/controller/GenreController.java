package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.AuthorEntity;
import com.example.api_sem_4.entity.GenreEntity;
import com.example.api_sem_4.sercice.GenreService;
import com.example.api_sem_4.sercice.SongService;
import com.example.api_sem_4.sercice.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Controller
public class GenreController {
    @Autowired
    GenreService genreService;

    @GetMapping("/")
    public String getGenre(Model model) {
        List<GenreEntity> genres = genreService.getGenre();
        model.addAttribute("genres", genres);
        return "main/home";
    }

    @GetMapping("/table-genre")
    public String getAllGenre(Model model, @RequestParam("name") Optional<String> name, @RequestParam(value = "page", defaultValue = "0") int page, @RequestParam(value = "size", defaultValue = "5") int size) {
        GenreEntity genreEntity = new GenreEntity();
        model.addAttribute("genres",genreEntity);

        List<GenreEntity> genrelist;
        int totalPage;
        if (name.isPresent()) {
            genrelist = genreService.getByName(name.get(), PageRequest.of(page, size));
            totalPage  = genreService.getTotalPageSearch(name.get(),PageRequest.of(page, size));
            model.addAttribute("t",1);
            model.addAttribute("namesearch",name.get());
        } else {
            genrelist = genreService.getAllGenre(PageRequest.of(page, size));
            totalPage  = genreService.getTotalPage(PageRequest.of(page, size));
        }
        model.addAttribute("totalPage", totalPage);
        model.addAttribute("size", size);
        model.addAttribute("page", page);
        model.addAttribute("genrelist",genrelist);

        return "admin/table-genre";
    }

    @PostMapping("/table-genre")
    public String upload(Model model, GenreEntity genreEntity){
        genreService.createGenre(genreEntity);
        return "redirect:/table-genre";
    }

    @GetMapping("/delete-genre/{id}")
    public String deleteGenre(Model model, @PathVariable int id) {
        if (id != 0) {
            genreService.deleteGenre(id);
        }
        return "redirect:/table-genre";
    }

    @GetMapping("/update-genre/{id}")
    public String updateGenre(Model model,@PathVariable int id) {
        GenreEntity genreEntity = genreService.getId(id);
        model.addAttribute("genres", genreEntity);
        return "admin/update-genre";
    }

    @PostMapping("/update-genre")
    public String updateGenre(Model model, GenreEntity genreEntity){
        genreService.updateGenre(genreEntity);
        return "redirect:/table-genre";
    }
}
