package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.ResponseFile;
import com.example.api_sem_4.entity.SongEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface SongService {
    Stream<SongEntity> getAllFiles();

    SongEntity store(MultipartFile file,MultipartFile image, SongEntity songEntity) throws IOException;

    SongEntity getFile(int id);

    List<SongEntity> getSong();
    List<SongEntity> getAllSong(Pageable pageable);

    Optional<SongEntity> findUserById(int id);

    List<SongEntity> findSongByName(String name);

    Page<SongEntity> getSongByName(String name, Pageable pageable);

    Page<SongEntity> findAll(Pageable pageable);

    void deleteSong(int id);
    int getTotalPage(Pageable pageable);

    List<SongEntity> getByName(String name, Pageable pageable);
    int getTotalPageSearch(String name, Pageable pageable);


    List<SongEntity> getTopSong(int top);
    List<SongEntity> getTopSongGenre(int top,String name);

    SongEntity storeUpdate(MultipartFile file,MultipartFile image,SongEntity songEntity) throws IOException;

    SongEntity getId(int id);
    Stream<SongEntity> getAllImage();

    Long getCount();
}
