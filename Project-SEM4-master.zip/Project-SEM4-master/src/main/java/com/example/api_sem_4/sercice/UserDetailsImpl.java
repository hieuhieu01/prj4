package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.CommentEntity;
import com.example.api_sem_4.entity.PlaylistEntity;
import com.example.api_sem_4.entity.UserEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.Lob;
import java.util.*;
import java.util.stream.Collectors;

public class UserDetailsImpl implements UserDetails {
    private static final long serialVersionUID = 1L;

    private int id;

    private String username;

    private String email;

    private String address;

    @JsonIgnore
    private String password;

    @Lob
    private byte[] avatar;

    private String phone;
    private String dateofbirth;
    private int roleid;

    @JsonIgnore
    List<PlaylistEntity> playlist;

    @JsonIgnore
    List<CommentEntity> comments;

    private Collection<? extends GrantedAuthority> authorities;

    public UserDetailsImpl(int id, String username, String email, String address, String password, byte[] avatar, int roleid, String phone, String dateofbirth, List<PlaylistEntity> playlist, List<CommentEntity> comments, Collection<? extends GrantedAuthority> authorities) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.address = address;
        this.password = password;
        this.avatar = avatar;
        this.roleid=roleid;
        this.phone=phone;
        this.dateofbirth=dateofbirth;
        this.playlist=playlist;
        this.comments=comments;
        this.authorities = authorities;
    }

    public static UserDetailsImpl build(UserEntity userEntity) {
        Set<GrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority(userEntity.getRole().getName()));

        return new UserDetailsImpl(
                userEntity.getId(),
                userEntity.getUsername(),
                userEntity.getEmail(),
                userEntity.getAddress(),
                userEntity.getPassword(),
                userEntity.getAvatar(),
                userEntity.getRoleid(),
                userEntity.getPhone(),
                userEntity.getDateofbirth(),
                userEntity.getPlaylist(),
                userEntity.getComments(),
                authorities);
    }
    public int getId() {
        return id;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public byte[] getAvatar() {
        return avatar;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        UserDetailsImpl user = (UserDetailsImpl) o;
        return Objects.equals(id, user.id);
    }

    public String getPhone() {
        return phone;
    }

    public String getDateofbirth() {
        return dateofbirth;
    }

    public int getRoleid() {
        return roleid;
    }
    public List<CommentEntity> getComments() {
        return comments;
    }

    public List<PlaylistEntity> getPlaylist() {
        return playlist;
    }
}
