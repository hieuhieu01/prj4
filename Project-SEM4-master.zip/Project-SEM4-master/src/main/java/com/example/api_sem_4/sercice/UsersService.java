package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.SongEntity;
import com.example.api_sem_4.entity.UserEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface UsersService {
    List<UserEntity> getUser();
    Optional<UserEntity> findUsersById(int id);
//    Page<UserEntity> getSongByName(String name, Pageable pageable);
    UserEntity createUser(MultipartFile file, UserEntity userEntity) throws IOException;

    UserEntity getId(int id);
    Stream<UserEntity> getAllImage();
    void updateAvatar(MultipartFile avatar, Integer id) throws IOException;
    void updateProfile(String username, String dateofbirth, String address, String phone, String email, Integer id);

    Long getCount();
}
