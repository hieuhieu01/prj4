package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.ReplyCommentEntity;
import com.example.api_sem_4.repository.ReplyCommentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReplyCommentServiceImp implements ReplyCommentService {
    @Autowired
    ReplyCommentRepo replyCommentRepo;

    @Override
    public ReplyCommentEntity createComment(ReplyCommentEntity replyCommentEntity) {
        return replyCommentRepo.save(replyCommentEntity);
    }
}
