//package com.example.api_sem_4.controller;
//
//import com.example.api_sem_4.entity.AlbumEntity;
//import com.example.api_sem_4.entity.SongEntity;
//import com.example.api_sem_4.entity.UserEntity;
//import com.example.api_sem_4.sercice.UserService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import java.util.Optional;
//
//@Controller
//public class ProfileController {
//    @Autowired
//    UserService userService;
//
//    @GetMapping("/album/{username}")
//    public String detailAlbum(@PathVariable("username") String username, Model model) {
//        UserDetails userEntity = userService.loadUserByUsername(username);
//        userEntity.ifPresent(albums -> model.addAttribute("albums", albums));
//
//        return "main/detail-album";
//    }
//
//}
