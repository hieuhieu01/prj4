package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.CommentEntity;
import com.example.api_sem_4.entity.SongEntity;

import java.util.Optional;

public interface CommentService {
    Optional<CommentEntity> findCommentById(int id);
    CommentEntity createComment(CommentEntity commentEntity);

    Long getCount();
}
