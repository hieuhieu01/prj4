package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.GenreEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface GenreRepo extends JpaRepository<GenreEntity, Integer> {
    @Query("select a from GenreEntity a where a.name like %:name%")
    Page<GenreEntity> findGenreByName(String name, Pageable pageable);

    @Query("select a from GenreEntity a where a.name like %:name%")
    List<GenreEntity> findByName(String name, Pageable pageable);

    @Query("select count(g) from GenreEntity g")
    Long getCount();
}
