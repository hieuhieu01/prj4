package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.SongEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface AlbumService {
    List<AlbumEntity> getAlbum();

    Optional<AlbumEntity> findAlbumById(int id);

    Page<AlbumEntity> getAlbumByName(String name, Pageable pageable);

    AlbumEntity createAlbum(MultipartFile file, AlbumEntity albumEntity) throws IOException;
    List<AlbumEntity> getAllAlbum(Pageable pageable);
    int getTotalPage(Pageable pageable);

    void deleteAlbum(int id);

    AlbumEntity getId(int id);
    AlbumEntity updateAlbum(MultipartFile file, AlbumEntity albumEntity) throws IOException;
    List<AlbumEntity> getByName(String name, Pageable pageable);
    int getTotalPageSearch(String name, Pageable pageable);
    Stream<AlbumEntity> getAllImage();

    Long getCount();
}
