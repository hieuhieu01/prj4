package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.SongPlayList;
import com.example.api_sem_4.repository.SongPlaylistRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SongPlaylistServiceImp implements SongPlaylistService {
    @Autowired
    SongPlaylistRepo songPlaylistRepo;

    @Override
    public SongPlayList createSongPlaylist(SongPlayList songPlayList) {
        return songPlaylistRepo.save(songPlayList);
    }
}
