package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.*;
import com.example.api_sem_4.sercice.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
public class SongController {
    @Autowired
    private SongService songService;

    @Autowired
    AlbumService albumService;

    @Autowired
    AuthorService authorService;

    @Autowired
    GenreService genreService;

    @Autowired
    SingerService singerService;

    @Autowired
    MvService mvService;

    @Autowired
    UsersService usersService;

    @Autowired
    CommentService commentService;

    @GetMapping("/dashboard")
    public String dashBoard(Model model) {
        List<SongEntity> songs;
        int top = 10;
        songs = songService.getTopSong(top);

        long countsong=songService.getCount();
        long countmv=mvService.getCount();
        long countuser=usersService.getCount();
        long countcomment=commentService.getCount();
        long countgenre=genreService.getCount();
        long countauthor=authorService.getCount();
        long countsinger=singerService.getCount();
        long countalbum=albumService.getCount();

        model.addAttribute("countsong", countsong);
        model.addAttribute("countmv", countmv);
        model.addAttribute("countuser", countuser);
        model.addAttribute("countcomment", countcomment);
        model.addAttribute("countgenre", countgenre);
        model.addAttribute("countauthor", countauthor);
        model.addAttribute("countsinger", countsinger);
        model.addAttribute("countalbum", countalbum);

        model.addAttribute("top",top);
        model.addAttribute("songs", songs);
        return "admin/dashboard";
    }

    @GetMapping("/table")
    public String table(Model model,  @RequestParam("name") Optional<String> name, Pageable pageable, @RequestParam(value = "page", defaultValue = "0") int page, @RequestParam(value = "size", defaultValue = "10") int size) {
        List<SongEntity> songs;
        int totalPage;
        if (name.isPresent()) {
            songs = songService.getByName(name.get(), PageRequest.of(page, size));
            totalPage  = songService.getTotalPageSearch(name.get(),PageRequest.of(page, size));
            model.addAttribute("t",1);
            model.addAttribute("namesearch",name.get());
        } else {
            songs = songService.getAllSong(PageRequest.of(page, size));
            totalPage  = songService.getTotalPage(PageRequest.of(page, size));
        }
        model.addAttribute("totalPage", totalPage);
        model.addAttribute("size", size);
        model.addAttribute("page", page);
        model.addAttribute("songs", songs);
        return "admin/table";
    }

    @GetMapping({"/add"})
    public String detail(Model model) {
        SongEntity songEntity = new SongEntity();
        model.addAttribute("songs", songEntity);
        return "admin/add-song";
    }

    @PostMapping("/save")
    public String upload(@RequestParam("file") MultipartFile file,@RequestParam("images") MultipartFile image, Model model, SongEntity songEntity) throws IOException {
        songService.store(file,image, songEntity);
        model.addAttribute("files", file);
        return "redirect:/table";

    }


    @ModelAttribute("list_album")
    public List<AlbumEntity> listAlbum() {
        return albumService.getAlbum();
    }

    @ModelAttribute("list_author")
    public List<AuthorEntity> listAuthor() {
        return authorService.getAuthor();
    }

    @ModelAttribute("list_genre")
    public List<GenreEntity> listGenre() {
        return genreService.getGenre();
    }

    @ModelAttribute("list_singer")
    public List<SingerEntity> list() {
        return singerService.getSinger();
    }

    @GetMapping("/search")
    public String search(Model model, @RequestParam("name") Optional<String> name, Pageable pageable) {
        Page<SongEntity> songs;
        Page<AlbumEntity> albums;
        Page<SingerEntity> singers;
        Page<MvEntity> mvs;
        if (name.isPresent()) {
            songs = songService.getSongByName(name.get(), pageable);
            albums = albumService.getAlbumByName(name.get(), pageable);
            singers = singerService.getSingerByName(name.get(), pageable);
            mvs=mvService.getMvByName(name.get(),pageable);
        } else {
            songs = songService.findAll(pageable);
            albums = null;
            singers = null;
            mvs=null;
        }
        model.addAttribute("songs", songs);
        model.addAttribute("albums", albums);
        model.addAttribute("singers", singers);
        model.addAttribute("mvs", mvs);
        return "main/search";
    }

//    @GetMapping("/search")
//    public String search(Model model, @RequestParam("name") Optional<String> name, Pageable pageable) {
//        Page<SongEntity> songs;
//        if (name.isPresent()) {
//            songs = songService.getSongByName(name.get(), pageable);
//        } else {
//            songs = songService.findAll(pageable);
//        }
//        model.addAttribute("songs", songs);
//        return "admin/table";
//    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(Model model, @PathVariable int id) {
        if (id != 0) {
            songService.deleteSong(id);
        }
        return "redirect:/table";
    }

    @GetMapping("/top")
    public String topSong(Model model) {
        List<SongEntity> songs;
        int top=10;
        songs = songService.getTopSong(top);
        int topvn=5;
        List<SongEntity> songvn;
        songvn = songService.getTopSongGenre(topvn,"việt nam");
        int topus=5;
        List<SongEntity> songus;
        songus = songService.getTopSongGenre(topus,"us-uk");
        int topkp=5;
        List<SongEntity> songkp;
        songkp = songService.getTopSongGenre(topkp,"k-pop");

        model.addAttribute("top",top);
        model.addAttribute("topvn",topvn);
        model.addAttribute("topus",topus);
        model.addAttribute("topkp",topkp);
        model.addAttribute("songs", songs);
        model.addAttribute("songvn", songvn);
        model.addAttribute("songus", songus);
        model.addAttribute("songkp", songkp);
        return "main/top";
    }

    @GetMapping("/update/{id}")
    public String updateSong(Model model,@PathVariable int id) {
        SongEntity songEntity = songService.getFile(id);
        model.addAttribute("songs", songEntity);
        return "admin/update-song";
    }

    @PostMapping("/update")
    public String updateSong(@RequestParam("file") MultipartFile file,@RequestParam("images") MultipartFile image, Model model,SongEntity songEntity) throws IOException {
        songService.storeUpdate(file,image,songEntity);
        model.addAttribute("files",file);
        return "redirect:/table";
    }


}

