package com.example.api_sem_4.entity;

import javax.persistence.*;

@Entity
@Table(name = "song_playlist")
public class SongPlayList {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "songId")
    private int songId;

    @Column(name = "playListId")
    private int playListId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }

    public int getPlayListId() {
        return playListId;
    }

    public void setPlayListId(int playListId) {
        this.playListId = playListId;
    }
}
