package com.example.api_sem_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSem4Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiSem4Application.class, args);
    }

}
