package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.CommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CommentRepo extends JpaRepository<CommentEntity,Integer> {
    @Query("select count(c) from CommentEntity c")
    Long getCount();
}
