package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.ResponseFile;
import com.example.api_sem_4.entity.SongEntity;
import com.example.api_sem_4.repository.SongRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class SongServiceImp implements SongService {
    @Autowired
    private SongRepo songRepo;


    @Override
    public Stream<SongEntity> getAllFiles() {
        return songRepo.findAll().stream();
    }

    public SongEntity store(MultipartFile file,MultipartFile image, SongEntity songEntity) throws IOException {
//        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        SongEntity SongEntity = new SongEntity(songEntity.getName(), image.getBytes(),
                songEntity.getDescription(), songEntity.getLyrics(), songEntity.getDuration(),
                songEntity.getView(), songEntity.getType(), file.getBytes(), songEntity.getGenreId(),
                songEntity.getAuthorId(), songEntity.getAlbumId(), songEntity.getSingers());

        return songRepo.save(SongEntity);
    }

    @Override
    public SongEntity getFile(int id) {
        return songRepo.findById(id).get();
    }

    @Override
    public List<SongEntity> getSong() {
        return songRepo.findAll();
    }

    @Override
    public List<SongEntity> getAllSong(Pageable pageable) {
        return songRepo.findAll(pageable).getContent();
    }

    @Override
    public Optional<SongEntity> findUserById(int id) {
        return songRepo.findById(id);
    }

    @Override
    public List<SongEntity> findSongByName(String name) {
        return songRepo.findAllByName(name);
    }

    @Override
    public Page<SongEntity> getSongByName(String name, Pageable pageable) {
        return songRepo.findSongByName(name, pageable);
    }

    @Override
    public Page<SongEntity> findAll(Pageable pageable) {
        return songRepo.findAll(pageable);
    }

    @Override
    public void deleteSong(int id) {
        songRepo.deleteById(id);
    }

    @Override
    public int getTotalPage(Pageable pageable) {
        return songRepo.findAll(pageable).getTotalPages();
    }

    @Override
    public List<SongEntity> getByName(String name, Pageable pageable) {
        return songRepo.findByName(name,pageable);
    }

    @Override
    public int getTotalPageSearch(String name, Pageable pageable) {
        return songRepo.findSongByName(name, pageable).getTotalPages();
    }

    @Override
    public List<SongEntity> getTopSong(int top) {
        return songRepo.findTopSong(top);
    }

    @Override
    public List<SongEntity> getTopSongGenre(int top, String name) {
        return songRepo.findTopSongGenre(top,name);
    }

    @Override
    public SongEntity getId(int id) {
        return songRepo.getById(id);
    }

    @Override
    public Stream<SongEntity> getAllImage() {
        return songRepo.findAll().stream();
    }

    @Override
    public Long getCount() {
        return songRepo.getCount();
    }

    @Override
    public SongEntity storeUpdate(MultipartFile file,MultipartFile image, SongEntity songEntity) throws IOException {
        SongEntity SongEntity = new SongEntity(songEntity.getId(),songEntity.getName(),image.getBytes(),
                songEntity.getDescription(),songEntity.getLyrics(),songEntity.getDuration(),
                songEntity.getView(),songEntity.getType(), file.getBytes(),songEntity.getGenreId(),
                songEntity.getAuthorId(), songEntity.getAlbumId(),songEntity.getSingers());

        return songRepo.save(SongEntity);
    }
}
