package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.ResponseFile;
import com.example.api_sem_4.entity.SongEntity;
import com.example.api_sem_4.sercice.AlbumService;
import com.example.api_sem_4.sercice.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class AlbumController {
    @Autowired
    AlbumService albumService;

    @Autowired
    SongService songService;

    @GetMapping("/album")
    public String getAllAlbum(Model model) {
        List<AlbumEntity> listAlbum = albumService.getAlbum();
        model.addAttribute("listAlbum", listAlbum);
        return "main/album";
    }

    @ModelAttribute("list_song")
    public List<SongEntity> listSong() {
        return songService.getSong();
    }


    @GetMapping("/album/{id}")
    public String detailAlbum(@PathVariable("id") int id, Model model) {
        Optional<AlbumEntity> albumById = albumService.findAlbumById(id);
        albumById.ifPresent(albums -> model.addAttribute("albums", albums));

        Optional<SongEntity> songDetail = songService.findUserById(id);
        songDetail.ifPresent(songs -> model.addAttribute("songs", songs));

        return "main/detail-album";
    }


    @GetMapping("/album/{id}/{sid}")
    public String songByAlbum(@PathVariable("id") int id, @PathVariable("sid") int sid, Model model) {
        Optional<AlbumEntity> albumById = albumService.findAlbumById(id);
        albumById.ifPresent(albums -> model.addAttribute("albums", albums));

        Optional<SongEntity> songDetail = songService.findUserById(sid);
        songDetail.ifPresent(songs -> model.addAttribute("songs", songs));

        List<ResponseFile> files = songService.getAllFiles().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/files/" + dbFile.getId() + ".mp3")
                    .toUriString();

            return new ResponseFile(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getType(),
                    dbFile.getData().length);
        }).collect(Collectors.toList());

        ResponseFile url = files.stream().filter((file) -> file.getId() == sid).findAny().get();
        model.addAttribute("files", url);

        return "main/song-by-album";
    }

    @GetMapping({"/table-album"})
    public String detail(Model model, @RequestParam("name") Optional<String> name, @RequestParam(value = "page", defaultValue = "0") int page, @RequestParam(value = "size", defaultValue = "3") int size) {
        AlbumEntity albumEntity = new AlbumEntity();
        model.addAttribute("albums",albumEntity);
        List<AlbumEntity> albumlist;
        int totalPage;
        if (name.isPresent()) {
            albumlist = albumService.getByName(name.get(), PageRequest.of(page, size));
            totalPage  = albumService.getTotalPageSearch(name.get(),PageRequest.of(page, size));
            model.addAttribute("t",1);
            model.addAttribute("namesearch",name.get());

        } else {
            albumlist = albumService.getAllAlbum(PageRequest.of(page, size));
            totalPage  = albumService.getTotalPage(PageRequest.of(page, size));
        }
        model.addAttribute("totalPage", totalPage);
        model.addAttribute("size", size);
        model.addAttribute("page", page);
        model.addAttribute("albumlist",albumlist);

        return "admin/add-album";
    }

    @PostMapping("/table-album")
    public String upload(@RequestParam("images") MultipartFile file, Model model, AlbumEntity albumEntity) throws IOException {
        albumService.createAlbum(file, albumEntity);
        return "redirect:/table-album";

    }

    @GetMapping("/delete-album/{id}")
    public String deleteAlbum(Model model, @PathVariable int id) {
        if (id != 0) {
            albumService.deleteAlbum(id);
        }
        return "redirect:/table-album";
    }

    @GetMapping("/update-album/{id}")
    public String updateAlbum(Model model,@PathVariable int id) {
        AlbumEntity albumEntity = albumService.getId(id);
        model.addAttribute("albums", albumEntity);
        return "admin/update-album";
    }

    @PostMapping("/update-album")
    public String updateAlbum(@RequestParam("images")MultipartFile file,Model model,AlbumEntity albumEntity) throws IOException {
        albumService.updateAlbum(file,albumEntity);
        return "redirect:/table-album";
    }
}
