package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.GenreEntity;
import com.example.api_sem_4.repository.GenreRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenreServiceImp implements GenreService {
    @Autowired
    GenreRepo genreRepo;

    @Override
    public List<GenreEntity> getGenre() {
        return genreRepo.findAll();
    }

    @Override
    public GenreEntity createGenre(GenreEntity genreEntity) {
        return genreRepo.save(genreEntity);
    }

    @Override
    public void deleteGenre(int id) {
        genreRepo.deleteById(id);
    }

    @Override
    public int getTotalPage(Pageable pageable) {
        return genreRepo.findAll(pageable).getTotalPages();
    }

    @Override
    public List<GenreEntity> getAllGenre(Pageable pageable) {
        return genreRepo.findAll(pageable).getContent();
    }

    @Override
    public GenreEntity getId(int id) {
        return genreRepo.getById(id);
    }


    @Override
    public GenreEntity updateGenre(GenreEntity genreEntity) {
        return genreRepo.save(genreEntity);
    }

    @Override
    public List<GenreEntity> getByName(String name, Pageable pageable) {
        return genreRepo.findByName(name,pageable);
    }

    @Override
    public int getTotalPageSearch(String name, Pageable pageable) {
        return genreRepo.findGenreByName(name,pageable).getTotalPages();
    }

    @Override
    public Long getCount() {
        return genreRepo.getCount();
    }
}
