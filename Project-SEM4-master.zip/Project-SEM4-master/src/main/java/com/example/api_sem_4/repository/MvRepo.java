package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.MvEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MvRepo extends JpaRepository<MvEntity, Integer> {
    @Query("select m from MvEntity m where m.name like %:name%")
    Page<MvEntity> findMvByName(String name, Pageable pageable);

    @Query("select m from MvEntity m where m.name like %:name%")
    List<MvEntity> findByName(String name, Pageable pageable);

    @Query("select count(m) from MvEntity m")
    Long getCount();
}
