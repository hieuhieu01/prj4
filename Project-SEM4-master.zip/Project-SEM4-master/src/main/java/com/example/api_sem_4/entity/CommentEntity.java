package com.example.api_sem_4.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "comment")
public class CommentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "content")
    private String name;

    @Column(name = "user_id")
    private int userId;

    @Column(name = "song_id")
    private int songId;

    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "created", nullable = false)
    private Date created = new Date();

//    public CommentEntity(int id, String name, int userId, int songId, LocalDateTime time, UserEntity user, SongEntity song) {
//        this.id = id;
//        this.name = name;
//        this.userId = userId;
//        this.songId = songId;
//        this.time = time;
//        this.user = user;
//        this.song = song;
//    }

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private UserEntity user ;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "song_id", insertable = false, updatable = false)
    private SongEntity song ;

    @JsonIgnore
    @OneToMany(mappedBy = "comment", fetch = FetchType.LAZY)
    List<ReplyCommentEntity> reply;



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }


    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public UserEntity getUser() {
        return user;
    }

    public void setUser(UserEntity user) {
        this.user = user;
    }

    public SongEntity getSong() {
        return song;
    }

    public void setSong(SongEntity song) {
        this.song = song;
    }

    public List<ReplyCommentEntity> getReply() {
        return reply;
    }

    public void setReply(List<ReplyCommentEntity> reply) {
        this.reply = reply;
    }
}
