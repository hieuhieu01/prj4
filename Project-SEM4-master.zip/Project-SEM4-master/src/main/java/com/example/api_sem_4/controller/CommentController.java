package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.CommentEntity;
import com.example.api_sem_4.entity.ReplyCommentEntity;
import com.example.api_sem_4.sercice.CommentService;
import com.example.api_sem_4.sercice.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;
import java.util.Optional;

@Controller
public class CommentController {
    @Autowired
    CommentService commentService;

    @Autowired
    UserService userService;

    @PostMapping("/add-comment")
    public String upload(CommentEntity commentEntity){
        commentService.createComment(commentEntity);
        int id = commentEntity.getSongId();
        return "redirect:/detail/" + id;

    }

    @GetMapping("/reply-comment/{id}")
    public String reply(Model model,@PathVariable int id, Principal principal) {
        Optional<CommentEntity> comment = commentService.findCommentById(id);
        comment.ifPresent(reply -> model.addAttribute("reply", reply));

        ReplyCommentEntity replyCommentEntity = new ReplyCommentEntity();
        model.addAttribute("replyCommentEntity",replyCommentEntity);

        UserDetails user = userService.loadUserByUsername(principal.getName());
        model.addAttribute("userlogin",user);

        return "main/reply-to-comment";
    }
}
