package com.example.api_sem_4.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "playlist")
public class PlaylistEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "imagePlaylist")
    @Lob
    private byte[] imagePlaylist;

    @Column(name = "userId")
    private int userId;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    private UserEntity user;

    @JsonIgnore
    @ManyToMany(mappedBy = "playlists")
    private List<SongEntity> songs;


//    @Lob
//    private byte[] data;

    public PlaylistEntity() {
    }

    public PlaylistEntity(String name, byte[] imagePlaylist, int userId) {
        this.name = name;
        this.imagePlaylist=imagePlaylist;
        this.userId=userId;
    }

    public PlaylistEntity(int id,String name, byte[] imagePlaylist, int userId) {
        this.id=id;
        this.name = name;
        this.imagePlaylist=imagePlaylist;
        this.userId=userId;
    }


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public UserEntity getUser() {
        return user;
    }

    public void setUser(UserEntity user) {
        this.user = user;
    }

    public List<SongEntity> getSongs() {
        return songs;
    }

    public void setSongs(List<SongEntity> songs) {
        this.songs = songs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getImagePlaylist() {
        return imagePlaylist;
    }

    public void setImagePlaylist(byte[] imagePlaylist) {
        this.imagePlaylist = imagePlaylist;
    }

    //    public byte[] getData() {
//        return data;
//    }
//
//    public void setData(byte[] data) {
//        this.data = data;
//    }
}
