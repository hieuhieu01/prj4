package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.SingerEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface SingerService {
    List<SingerEntity> getSinger();

    Optional<SingerEntity> findSingerById(int id);

    Page<SingerEntity> getSingerByName(String name, Pageable pageable);

    SingerEntity createSinger(MultipartFile avatar,MultipartFile image, SingerEntity singerEntity) throws IOException;
    List<SingerEntity> getAllSinger(Pageable pageable);
    int getTotalPage(Pageable pageable);

    void deleteSinger(int id);

    SingerEntity getId(int id);
    SingerEntity updateSinger(MultipartFile avatar,MultipartFile image, SingerEntity singerEntity) throws IOException;
    List<SingerEntity> getByName(String name, Pageable pageable);
    int getTotalPageSearch(String name, Pageable pageable);

    Stream<SingerEntity> getAllImage();

    Long getCount();
}
