package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.*;
import com.example.api_sem_4.sercice.SingerService;
import com.example.api_sem_4.sercice.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class SingerController {
    @Autowired
    SingerService singerService;

    @Autowired
    SongService songService;

    @GetMapping("/singer/{id}")
    public String detailSinger(@PathVariable("id") int id, Model model) {
        Optional<SingerEntity> singerById = singerService.findSingerById(id);
        singerById.ifPresent(singers -> model.addAttribute("singers", singers));

        Optional<SongEntity> songDetail = songService.findUserById(id);
        songDetail.ifPresent(songs -> model.addAttribute("songs", songs));

        return "main/detail-singer";
    }

    @GetMapping("/singer/{id}/{sid}")
    public String songByAlbum(@PathVariable("id") int id, @PathVariable("sid") int sid, Model model) {
        Optional<SingerEntity> singerById = singerService.findSingerById(id);
        singerById.ifPresent(singers -> model.addAttribute("singers", singers));

        Optional<SongEntity> songDetail = songService.findUserById(sid);
        songDetail.ifPresent(songs -> model.addAttribute("songs", songs));

        List<ResponseFile> files = songService.getAllFiles().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/files/" + dbFile.getId()+ ".mp3")
                    .toUriString();

            return new ResponseFile(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getType(),
                    dbFile.getData().length);
        }).collect(Collectors.toList());

        ResponseFile url = files.stream().filter((file) -> file.getId() == sid).findAny().get();
        model.addAttribute("files", url);

        return "main/song-by-singer";
    }

    @GetMapping({"/add-singer"})
    public String addSinger(Model model) {
        SingerEntity singerEntity = new SingerEntity();
        model.addAttribute("singer",singerEntity);

        return "admin/add-singer";
    }

    @PostMapping("/add-singer")
    public String addSinger(@RequestParam("avatarsinger") MultipartFile avatar,@RequestParam("images") MultipartFile image, SingerEntity singerEntity) throws IOException {
        singerService.createSinger(avatar,image,singerEntity);
        return "redirect:/table-singer";
    }

    @GetMapping({"/table-singer"})
    public String detail(Model model, @RequestParam("name") Optional<String> name, @RequestParam(value = "page", defaultValue = "0") int page, @RequestParam(value = "size", defaultValue = "7") int size) {
        SingerEntity singerEntity = new SingerEntity();
        model.addAttribute("singer",singerEntity);

        List<SingerEntity> singerlist;
        int totalPage;
        if (name.isPresent()) {
            singerlist = singerService.getByName(name.get(), PageRequest.of(page, size));
            totalPage  = singerService.getTotalPageSearch(name.get(),PageRequest.of(page, size));
            model.addAttribute("t",1);
            model.addAttribute("namesearch",name.get());
        } else {
            singerlist = singerService.getAllSinger(PageRequest.of(page, size));
            totalPage  = singerService.getTotalPage(PageRequest.of(page, size));
        }
        model.addAttribute("totalPage", totalPage);
        model.addAttribute("size", size);
        model.addAttribute("page", page);
        model.addAttribute("singerlist",singerlist);

        return "admin/table-singer";
    }

    @GetMapping("/delete-singer/{id}")
    public String deleteSinger(Model model, @PathVariable int id) {
        if (id != 0) {
            singerService.deleteSinger(id);
        }
        return "redirect:/table-singer";
    }

    @GetMapping("/update-singer/{id}")
    public String updateSinger(Model model,@PathVariable int id) {
        SingerEntity singerEntity = singerService.getId(id);
        model.addAttribute("singers", singerEntity);
        return "admin/update-singer";
    }

    @PostMapping("/update-singer")
    public String updateSinger(@RequestParam("avatarsinger") MultipartFile avatar,@RequestParam("images")MultipartFile image,SingerEntity singerEntity) throws IOException {
        singerService.updateSinger(avatar,image,singerEntity);
        return "redirect:/table-singer";
    }
}
