package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.CommentEntity;
import com.example.api_sem_4.entity.ReplyCommentEntity;

public interface ReplyCommentService {
    ReplyCommentEntity createComment(ReplyCommentEntity replyCommentEntity);
}
