package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.repository.AlbumRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class AlbumServiceImp implements AlbumService {
    @Autowired
    AlbumRepo albumRepo;

    @Override
    public List<AlbumEntity> getAlbum() {
        return albumRepo.findAll();
    }

    @Override
    public Optional<AlbumEntity> findAlbumById(int id) {
        return albumRepo.findById(id);
    }

    @Override
    public Page<AlbumEntity> getAlbumByName(String name, Pageable pageable) {
        return albumRepo.findAlbumByName(name, pageable);
    }

    @Override
    public AlbumEntity createAlbum(MultipartFile file, AlbumEntity albumEntity) throws IOException {
        AlbumEntity albumEntity1= new AlbumEntity(albumEntity.getName(), file.getBytes());
        return albumRepo.save(albumEntity1);
    }

    @Override
    public List<AlbumEntity> getAllAlbum(Pageable pageable) {
        return albumRepo.findAll(pageable).getContent();
    }


    @Override
    public int getTotalPage(Pageable pageable) {
        return albumRepo.findAll(pageable).getTotalPages();
    }

    @Override
    public void deleteAlbum(int id) {
        albumRepo.deleteById(id);
    }

    @Override
    public AlbumEntity getId(int id) {
        return albumRepo.getById(id);
    }

    @Override
    public AlbumEntity updateAlbum(MultipartFile file, AlbumEntity albumEntity) throws IOException {
        AlbumEntity albumEntity1= new AlbumEntity(albumEntity.getId(),albumEntity.getName(), file.getBytes());
        return albumRepo.save(albumEntity1);
    }

    @Override
    public List<AlbumEntity> getByName(String name, Pageable pageable) {
        return albumRepo.findByName(name,pageable);
    }

    @Override
    public int getTotalPageSearch(String name, Pageable pageable) {
        return albumRepo.findAlbumByName(name, pageable).getTotalPages();
    }

    @Override
    public Stream<AlbumEntity> getAllImage() {
        return albumRepo.findAll().stream();
    }

    @Override
    public Long getCount() {
        return albumRepo.getCount();
    }
}
