package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.*;
import com.example.api_sem_4.message.ResponseMessage;
import com.example.api_sem_4.sercice.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@CrossOrigin("http://localhost:8080")
public class WebController {
    @Autowired
    private SongService songService;

    @Autowired
    private SingerService singerService;

    @Autowired
    private AlbumService albumService;

    @Autowired
    PlaylistService playlistService;

    @Autowired
    CommentService commentService;

    @Autowired
    UsersService usersService;

    @Autowired
    UserService userService;

    @Autowired
    MvService mvService;

    @Autowired
    private PasswordEncoder passwordEncoder;


    // Hien thi audio
    @GetMapping({"/index"})
    public String index(Model model) {
        List<ResponseFile> files = songService.getAllFiles().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/files/" + dbFile.getId())
                    .toUriString();

            return new ResponseFile(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getType(),
                    dbFile.getData().length);
        }).collect(Collectors.toList());
        model.addAttribute("files", files);
        return "index";
    }


    // Upload in Postman
    @PostMapping("/upload")
    public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file,@RequestParam("image") MultipartFile image, SongEntity songEntity) {
        String message = "";
        try {
            songService.store(file,image, songEntity);

            message = "Uploaded the file successfully: " + file.getOriginalFilename();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
        } catch (Exception e) {
            message = "Could not upload the file: " + file.getOriginalFilename() + "!";
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
        }
    }

    // lay duong link nhac trong postman
    @GetMapping("/files")
    public ResponseEntity<List<ResponseFile>> getListFiles() {
        List<ResponseFile> files = songService.getAllFiles().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/files/" + dbFile.getId())
//                    .path(dbFile.getId())
                    .toUriString();

            return new ResponseFile(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getType(),
                    dbFile.getData().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }

    // tao duong dan chi file nhac
    @GetMapping("/files/{id}.mp3")
    public ResponseEntity<byte[]> getFile(@PathVariable int id) {
        SongEntity song = songService.getFile(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + song.getName() + ".mp3" + "\"")
                .body(song.getData());
    }

    // lay danh sach nhac in postman
    @GetMapping("/all")
    public ResponseEntity<Stream<SongEntity>> getAll() {
        Stream<SongEntity> all = songService.getAllFiles();
        return ResponseEntity.ok(all);
    }


    // tao duong dan chi file anh playlist
    @GetMapping("/images/playlist/{id}")
    public ResponseEntity<byte[]> getImagePlaylist(@PathVariable int id) {
        PlaylistEntity playlist= playlistService.getFile(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + playlist.getName() + "\"")
                .body(playlist.getImagePlaylist());
    }

    // lay duong link anh playlist trong postman
    @GetMapping("/images/playlist")
    public ResponseEntity<List<ResponseImage>> getListImagesPlaylist() {
        List<ResponseImage> files = playlistService.getAllImage().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/images/playlist/" + dbFile.getId())
//                    .path(dbFile.getId())
                    .toUriString();

            return new ResponseImage(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getImagePlaylist().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    //    user image
    @GetMapping("/images/user/{id}")
    public ResponseEntity<byte[]> getImageUser(@PathVariable int id) {
        UserEntity user=usersService.getId(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + user.getUsername() + "\"")
                .body(user.getAvatar());
    }

    @GetMapping("/images/user")
    public ResponseEntity<List<ResponseImage>> getListImagesUser() {
        List<ResponseImage> files = usersService.getAllImage().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/images/user/" + dbFile.getId())
                    .toUriString();

            return new ResponseImage(
                    dbFile.getId(),
                    dbFile.getUsername(),
                    fileDownloadUri,
                    dbFile.getAvatar().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    //    album image
    @GetMapping("/images/album/{id}")
    public ResponseEntity<byte[]> getImageAlbum(@PathVariable int id) {
        AlbumEntity album=albumService.getId(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + album.getName() + "\"")
                .body(album.getImage());
    }

    @GetMapping("/images/album")
    public ResponseEntity<List<ResponseImage>> getListImagesAlbum() {
        List<ResponseImage> files = albumService.getAllImage().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/images/album/" + dbFile.getId())
                    .toUriString();

            return new ResponseImage(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getImage().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    //    mv image
    @GetMapping("/images/mv/{id}")
    public ResponseEntity<byte[]> getImageMv(@PathVariable int id) {
        MvEntity mv=mvService.getId(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + mv.getName() + "\"")
                .body(mv.getImage());
    }

    @GetMapping("/images/mv")
    public ResponseEntity<List<ResponseImage>> getListImagesMv() {
        List<ResponseImage> files = mvService.getAllImage().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/images/mv/" + dbFile.getId())
                    .toUriString();

            return new ResponseImage(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getImage().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    // mv url
    @GetMapping("/mv-url/{id}")
    public ResponseEntity<byte[]> getUrlMv(@PathVariable int id) {
        MvEntity mv = mvService.getId(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + mv.getName() + "\"")
                .body(mv.getData_mv());
    }

    @GetMapping("/mv-url")
    public ResponseEntity<List<ResponseMv>> getListMvUrl() {
        List<ResponseMv> files = mvService.getAllUrl().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/mv-url/" + dbFile.getId())
                    .toUriString();

            return new ResponseMv(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getData_mv().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    //    singer image
    @GetMapping("/images/singer/{id}")
    public ResponseEntity<byte[]> getImageSinger(@PathVariable int id) {
        SingerEntity singer=singerService.getId(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + singer.getName() + "\"")
                .body(singer.getImage());
    }

    @GetMapping("/images/singer")
    public ResponseEntity<List<ResponseImage>> getListImagesSinger() {
        List<ResponseImage> files = singerService.getAllImage().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/images/singer/" + dbFile.getId())
                    .toUriString();

            return new ResponseImage(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getImage().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    //    singer image avatar
    @GetMapping("/images/singer/avatar/{id}")
    public ResponseEntity<byte[]> getImageSingerAvatar(@PathVariable int id) {
        SingerEntity singer=singerService.getId(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + singer.getName() + "\"")
                .body(singer.getAvatar());
    }

    @GetMapping("/images/singer/avatar")
    public ResponseEntity<List<ResponseImage>> getListImagesSingerAvatar() {
        List<ResponseImage> files = singerService.getAllImage().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/images/singer/avatar/" + dbFile.getId())
                    .toUriString();

            return new ResponseImage(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getAvatar().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    //    song image
    @GetMapping("/images/song/{id}")
    public ResponseEntity<byte[]> getImageSong(@PathVariable int id) {
        SongEntity song=songService.getId(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + song.getName() + "\"")
                .body(song.getImage());
    }

    @GetMapping("/images/song")
    public ResponseEntity<List<ResponseImage>> getListImagesSong() {
        List<ResponseImage> files = songService.getAllImage().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/images/song/" + dbFile.getId())
                    .toUriString();

            return new ResponseImage(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getImage().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }


    @ModelAttribute("list_playlists")
    public List<PlaylistEntity> listPl() {
        return playlistService.getPlaylist();
    }

    @ModelAttribute("list_song")
    public List<SongEntity> listSong() {
        return songService.getSong();
    }

    @GetMapping("/detail/{id}")
    public String detailSong(@PathVariable("id") int id, Model model, Principal principal) {
        Optional<SongEntity> songDetail = songService.findUserById(id);
        songDetail.ifPresent(songs -> model.addAttribute("songs", songs));
        //model.addAttribute("songDetail", songDetail);

        CommentEntity commentEntity = new CommentEntity();
        model.addAttribute("commentEntity",commentEntity);

        List<ResponseFile> files = songService.getAllFiles().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/files/" + dbFile.getId() + ".mp3")
                    .toUriString();

            return new ResponseFile(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getType(),
                    dbFile.getData().length);
        }).collect(Collectors.toList());

        ResponseFile url = files.stream().filter((file) -> file.getId() == id).findAny().get();
        model.addAttribute("files", url);

        SongPlayList songPlayList = new SongPlayList();
        model.addAttribute("playlist", songPlayList);

        UserDetails user = userService.loadUserByUsername(principal.getName());
        model.addAttribute("userlogin",user);

        return "main/detail-song";
    }


    //Errorr
    @GetMapping({"/errorr"})
    private String error() {
        return "404";
    }

    //Login
    @GetMapping("/login")
    private String login() {
        return "login";
    }

    //REGISTER
    @GetMapping({"/register"})
    private String register(Model model){
        UserEntity userEntity = new UserEntity();
        model.addAttribute("users",userEntity);
        return "register";
    }

    @PostMapping("/register")
    public String upload(@RequestParam("images") MultipartFile file, UserEntity userEntity) throws IOException {
        String encodedPassword = passwordEncoder.encode(userEntity.getPassword());
        UserEntity userEntity1 = new UserEntity(userEntity.getUsername(),encodedPassword,userEntity.getAddress(),userEntity.getPhone(),userEntity.getEmail(),userEntity.getDateofbirth(),userEntity.getRoleid(),file.getBytes());

        usersService.createUser(file,userEntity1);
        return "redirect:/login";

    }

}
