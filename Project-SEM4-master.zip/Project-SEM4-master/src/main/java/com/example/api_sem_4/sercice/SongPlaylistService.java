package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.SongPlayList;

public interface SongPlaylistService {
    SongPlayList createSongPlaylist(SongPlayList songPlayList);
}
