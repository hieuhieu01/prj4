package com.example.api_sem_4.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "song")
public class SongEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "name")
    private String name;

    @Lob
    @Column(name = "image")
    private byte[] image;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "lyrics", columnDefinition = "TEXT")
    private String lyrics;

    @Column(name = "duration")
    private String duration;

    @Column(name = "view")
    private int view;

    @Column(name = "type")
    private String type;

    @Lob
    @Column(name = "data")
    private byte[] data;

    @Column(name = "genreId")
    private int genreId;

    @Column(name = "authorId")
    private int authorId;

    @Column(name = "albumId")
    private int albumId;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "genreId", insertable = false, updatable = false)
    private GenreEntity genre;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "authorId", insertable = false, updatable = false)
    private AuthorEntity author;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "albumId", insertable = false, updatable = false)
    private AlbumEntity album;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "song_singer",
            joinColumns = @JoinColumn(name = "songId"),
            inverseJoinColumns = @JoinColumn(name = "singerId")
    )
    private List<SingerEntity> singers;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "song_playlist",
            joinColumns = @JoinColumn(name = "songId"),
            inverseJoinColumns = @JoinColumn(name = "playListId")
    )
    private List<PlaylistEntity> playlists;


    @JsonIgnore
    @OneToMany(mappedBy = "song", fetch = FetchType.LAZY)
    List<CommentEntity> comments;


    public List<PlaylistEntity> getPlaylists() {
        return playlists;
    }

    public void setPlaylists(List<PlaylistEntity> playlists) {
        this.playlists = playlists;
    }

    public List<SingerEntity> getSingers() {
        return singers;
    }

    public void setSingers(List<SingerEntity> singers) {
        this.singers = singers;
    }

    public SongEntity() {
    }


    public SongEntity(String name, byte[] image, String description, String lyrics, String duration, int view, String type, byte[] data, int genreId, int authorId, int albumId, List<SingerEntity> singers) {
        this.name = name;
        this.image = image;
        this.description = description;
        this.lyrics = lyrics;
        this.duration = duration;
        this.view = view;
        this.type = type;
        this.data = data;
        this.genreId = genreId;
        this.authorId = authorId;
        this.albumId = albumId;
        this.singers = singers;
    }

//    public SongEntity(String name, int genreId, int authorId, int albumId, List<SingerEntity> singers) {
//        this.name = name;
//        this.genreId = genreId;
//        this.authorId = authorId;
//        this.albumId = albumId;
//        this.singers = singers;
//    }


    public SongEntity(int id, String name, byte[] image, String description, String lyrics, String duration, int view, String type, byte[] data, int genreId, int authorId, int albumId, List<SingerEntity> singers) {
        this.id = id;
        this.name = name;
        this.image = image;
        this.description = description;
        this.lyrics = lyrics;
        this.duration = duration;
        this.view = view;
        this.type = type;
        this.data = data;
        this.genreId = genreId;
        this.authorId = authorId;
        this.albumId = albumId;
        this.singers = singers;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLyrics() {
        return lyrics;
    }

    public void setLyrics(String lyrics) {
        this.lyrics = lyrics;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public int getView() {
        return view;
    }

    public void setView(int view) {
        this.view = view;
    }

    public int getGenreId() {
        return genreId;
    }

    public void setGenreId(int genreId) {
        this.genreId = genreId;
    }

    public int getAuthorId() {
        return authorId;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public GenreEntity getGenre() {
        return genre;
    }

    public void setGenre(GenreEntity genre) {
        this.genre = genre;
    }

    public AuthorEntity getAuthor() {
        return author;
    }

    public void setAuthor(AuthorEntity author) {
        this.author = author;
    }

    public AlbumEntity getAlbum() {
        return album;
    }

    public void setAlbum(AlbumEntity album) {
        this.album = album;
    }

    public List<CommentEntity> getComments() {
        return comments;
    }

    public void setComments(List<CommentEntity> comments) {
        this.comments = comments;
    }
}
