package com.example.api_sem_4.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "mv")
public class MvEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "name")
    private String name;

    @Lob
    @Column(name = "data_mv")
    private byte[] data_mv;

    @Lob
    @Column(name = "image")
    private byte[] image;

    @Column(name = "description")
    private String description;

    @Column(name = "lyrics")
    private String lyrics;

    @Column(name = "duration")
    private String duration;

    @Column(name = "view")
    private int view;

    @Column(name = "author_id")
    private int author_id;

    @Column(name = "genre_id")
    private int genre_id;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "genre_id", insertable = false, updatable = false)
    private GenreEntity genre_mv;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "author_id", insertable = false, updatable = false)
    private AuthorEntity author_mv;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "mv_singer",
            joinColumns = @JoinColumn(name = "mv_id"),
            inverseJoinColumns = @JoinColumn(name = "singer_id")
    )
    private List<SingerEntity> singers;

    public MvEntity(){}

    public MvEntity(int id, String name, byte[] data_mv, byte[] image, String description, String lyrics, String duration, int view, int author_id, int genre_id, List<SingerEntity> singers) {
        this.id = id;
        this.name = name;
        this.data_mv = data_mv;
        this.image = image;
        this.description = description;
        this.lyrics = lyrics;
        this.duration = duration;
        this.view = view;
        this.author_id = author_id;
        this.genre_id = genre_id;
        this.singers = singers;
    }

    public MvEntity(String name, byte[] data_mv, byte[] image, String description, String lyrics, String duration, int view, int author_id, int genre_id, List<SingerEntity> singers) {
        this.name = name;
        this.data_mv = data_mv;
        this.image = image;
        this.description = description;
        this.lyrics = lyrics;
        this.duration = duration;
        this.view = view;
        this.author_id = author_id;
        this.genre_id = genre_id;
        this.singers = singers;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getData_mv() {
        return data_mv;
    }

    public void setData_mv(byte[] data_mv) {
        this.data_mv = data_mv;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLyrics() {
        return lyrics;
    }

    public void setLyrics(String lyrics) {
        this.lyrics = lyrics;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public int getView() {
        return view;
    }

    public void setView(int view) {
        this.view = view;
    }

    public int getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(int author_id) {
        this.author_id = author_id;
    }

    public int getGenre_id() {
        return genre_id;
    }

    public void setGenre_id(int genre_id) {
        this.genre_id = genre_id;
    }

    public GenreEntity getGenre_mv() {
        return genre_mv;
    }

    public void setGenre_mv(GenreEntity genre_mv) {
        this.genre_mv = genre_mv;
    }

    public AuthorEntity getAuthor_mv() {
        return author_mv;
    }

    public void setAuthor_mv(AuthorEntity author_mv) {
        this.author_mv = author_mv;
    }

    public List<SingerEntity> getSingers() {
        return singers;
    }

    public void setSingers(List<SingerEntity> singers) {
        this.singers = singers;
    }
}
