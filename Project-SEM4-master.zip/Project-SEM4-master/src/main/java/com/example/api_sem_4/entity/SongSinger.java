package com.example.api_sem_4.entity;

import javax.persistence.*;

@Entity
@Table(name = "song_singer")
public class SongSinger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "songId")
    private int songId;

    @Column(name = "singerId")
    private int singerId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }

    public int getSingerId() {
        return singerId;
    }

    public void setSingerId(int singerId) {
        this.singerId = singerId;
    }
}
