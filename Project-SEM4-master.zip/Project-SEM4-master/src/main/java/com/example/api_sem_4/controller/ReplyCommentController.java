package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.CommentEntity;
import com.example.api_sem_4.entity.ReplyCommentEntity;
import com.example.api_sem_4.sercice.ReplyCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ReplyCommentController {
    @Autowired
    ReplyCommentService replyCommentService;

    @PostMapping("/add-reply-comment")
    public String upload(ReplyCommentEntity replyCommentEntity, CommentEntity commentEntity){
        replyCommentService.createComment(replyCommentEntity);
        int id = replyCommentEntity.getCommentId();
        return "redirect:/reply-comment/" + id;
    }

}
