package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.AuthorEntity;
import com.example.api_sem_4.entity.GenreEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AuthorRepo extends JpaRepository<AuthorEntity, Integer> {
    @Query("select a from AuthorEntity a where a.name like %:name%")
    Page<AuthorEntity> findAuthorByName(String name, Pageable pageable);

    @Query("select a from AuthorEntity a where a.name like %:name%")
    List<AuthorEntity> findByName(String name, Pageable pageable);

    @Query("select count(a) from AuthorEntity a")
    Long getCount();
}
