package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.SingerEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SingerRepo extends JpaRepository<SingerEntity, Integer> {
    @Query("select s from SingerEntity s where s.name like %:name%")
    Page<SingerEntity> findSingerByName(String name, Pageable pageable);

    @Query("select a from SingerEntity a where a.name like %:name%")
    List<SingerEntity> findByName(String name, Pageable pageable);

    @Query("select count(s) from SingerEntity s")
    Long getCount();
}
