package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.SingerEntity;
import com.example.api_sem_4.entity.SongEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SongRepo extends JpaRepository<SongEntity, Integer> {
    @Query("select s from SongEntity s where s.name like %:name%")
    List<SongEntity> findAllByName(String name);


    @Query("select s from SongEntity s where s.name like %:name%")
    Page<SongEntity> findSongByName(String name, Pageable pageable);

    @Query("select s from SongEntity s where s.name like %:name%")
    List<SongEntity> findByName(String name, Pageable pageable);


    @Query(value = "select * from song order by view desc limit :top", nativeQuery = true)
    List<SongEntity> findTopSong(int top);

    @Query(value = "select * from song inner join genre on song.genre_id = genre.id where genre.name=:name order by view desc limit :top", nativeQuery = true)
    List<SongEntity> findTopSongGenre(int top,String name);

    @Query("select count(s) from SongEntity s")
    Long getCount();
}
