package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.*;
import com.example.api_sem_4.sercice.PlaylistService;
import com.example.api_sem_4.sercice.SongService;
import com.example.api_sem_4.sercice.UserService;
import com.example.api_sem_4.sercice.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class PlaylistController {
    private static final Path CURRENT_FOLDER = Paths.get(System.getProperty("user.dir"));

    @Autowired
    PlaylistService playlistService;

    @Autowired
    UsersService usersService;

    @Autowired
    UserService userService;

    @Autowired
    SongService songService;

    @ModelAttribute("list_user")
    public List<UserEntity> listUser() {
        return usersService.getUser();
    }

    @GetMapping("/playlist")
    public String playlist(Model model, Principal principal) {
        UserDetails user=userService.loadUserByUsername(principal.getName());
        model.addAttribute("user",user);

        return "main/playlist";
    }

    @GetMapping({"/addPl"})
    public String detail(Model model, Principal principal) {
        PlaylistEntity playlistEntity = new PlaylistEntity();
        model.addAttribute("playlist", playlistEntity);
        UserDetails user=userService.loadUserByUsername(principal.getName());
        model.addAttribute("userlogin",user);
        return "main/add-playlist";
    }

    @PostMapping("/savePl")
    public String addPl(@RequestParam("images") MultipartFile file, Model model, PlaylistEntity playlistEntity) throws IOException {
        playlistService.store(file, playlistEntity);
        model.addAttribute("files", file);
        return "redirect:/playlist";

    }

    @GetMapping("/playlist/{id}")
    public String detailPlaylist(@PathVariable("id") int id, Model model, Principal principal) {
        UserDetails user=userService.loadUserByUsername(principal.getName());
        model.addAttribute("user",user);

        Optional<PlaylistEntity> playlistId = playlistService.findPlaylistById(id);
        playlistId.ifPresent(playlist -> model.addAttribute("playlists", playlist));

        Optional<SongEntity> songDetail = songService.findUserById(id);
        songDetail.ifPresent(songs -> model.addAttribute("songs", songs));

        return "main/detail-playlist";
    }

    @GetMapping("/playlist/{id}/{sid}")
    public String songByPlaylist(@PathVariable("id") int id, @PathVariable("sid") int sid, Principal principal, Model model) {
        UserDetails user=userService.loadUserByUsername(principal.getName());
        model.addAttribute("user",user);

        Optional<PlaylistEntity> playlistId = playlistService.findPlaylistById(id);
        playlistId.ifPresent(playlist -> model.addAttribute("playlists", playlist));

        Optional<SongEntity> songDetail = songService.findUserById(sid);
        songDetail.ifPresent(songs -> model.addAttribute("songs", songs));

        List<ResponseFile> files = songService.getAllFiles().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/files/" + dbFile.getId() + ".mp3")
                    .toUriString();

            return new ResponseFile(
                    dbFile.getId(),
                    dbFile.getName(),
                    fileDownloadUri,
                    dbFile.getType(),
                    dbFile.getData().length);
        }).collect(Collectors.toList());

        ResponseFile url = files.stream().filter((file) -> file.getId() == sid).findAny().get();
        model.addAttribute("files", url);

        return "main/song-by-playlist";
    }

    @GetMapping("/delete-playlist/{id}")
    public String deletePlaylist(Model model, @PathVariable int id) {
        if (id != 0) {
            playlistService.remove(id);
        }
        return "redirect:/playlist";
    }

    @GetMapping("/update-playlist/{id}")
    public String updatePlaylist(Model model,@PathVariable int id) {
        PlaylistEntity playlistEntity = playlistService.getId(id);
        model.addAttribute("playlist", playlistEntity);
        return "main/edit-playlist";
    }

    @PostMapping("/update-playlist")
    public String updatePlaylist(@RequestParam("images") MultipartFile file,Model model,PlaylistEntity playlistEntity) throws IOException {
        playlistService.update(file, playlistEntity);
        model.addAttribute("files", file);
        return "redirect:/playlist";

    }

}
