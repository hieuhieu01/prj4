package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.SingerEntity;
import com.example.api_sem_4.repository.SingerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class SingerServiceImp implements SingerService {
    @Autowired
    SingerRepo singerRepo;

    @Override
    public List<SingerEntity> getSinger() {
        return singerRepo.findAll();
    }

    @Override
    public Optional<SingerEntity> findSingerById(int id) {
        return singerRepo.findById(id);
    }

    @Override
    public Page<SingerEntity> getSingerByName(String name, Pageable pageable) {
        return singerRepo.findSingerByName(name, pageable);
    }

    @Override
    public SingerEntity createSinger(MultipartFile avatar, MultipartFile image, SingerEntity singerEntity) throws IOException {
        SingerEntity singerEntity1 = new SingerEntity(singerEntity.getName(),singerEntity.getYearOfBirth(),singerEntity.getGender(),image.getBytes(),avatar.getBytes(),singerEntity.getBiography());
        return singerRepo.save(singerEntity1);
    }

    @Override
    public List<SingerEntity> getAllSinger(Pageable pageable) {
        return singerRepo.findAll(pageable).getContent();
    }

    @Override
    public int getTotalPage(Pageable pageable) {
        return singerRepo.findAll(pageable).getTotalPages();
    }

    @Override
    public void deleteSinger(int id) {
        singerRepo.deleteById(id);
    }

    @Override
    public SingerEntity getId(int id) {
        return singerRepo.getById(id);
    }

    @Override
    public SingerEntity updateSinger(MultipartFile avatar, MultipartFile image, SingerEntity singerEntity) throws IOException {
        SingerEntity singerEntity1 = new SingerEntity(singerEntity.getId(),singerEntity.getName(),singerEntity.getYearOfBirth(),singerEntity.getGender(),image.getBytes(),avatar.getBytes(),singerEntity.getBiography());
        return singerRepo.save(singerEntity1);
    }

    @Override
    public List<SingerEntity> getByName(String name, Pageable pageable) {
        return singerRepo.findByName(name,pageable);
    }

    @Override
    public int getTotalPageSearch(String name, Pageable pageable) {
        return singerRepo.findSingerByName(name,pageable).getTotalPages();
    }

    @Override
    public Stream<SingerEntity> getAllImage() {
        return singerRepo.findAll().stream();
    }

    @Override
    public Long getCount() {
        return singerRepo.getCount();
    }
}
