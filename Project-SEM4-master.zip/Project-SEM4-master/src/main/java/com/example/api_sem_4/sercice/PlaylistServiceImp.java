package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.PlaylistEntity;
import com.example.api_sem_4.repository.PlaylistRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class PlaylistServiceImp implements PlaylistService {
    @Autowired
    private PlaylistRepo playlistRepo;

    @Override
    public Stream<PlaylistEntity> getAllImage() {
        return playlistRepo.findAll().stream();
    }

    @Override
    public PlaylistEntity store(MultipartFile file, PlaylistEntity playlistEntity) throws IOException {
        PlaylistEntity playlistEntity1 = new PlaylistEntity(playlistEntity.getName(), file.getBytes(), playlistEntity.getUserId());

        return playlistRepo.save(playlistEntity1);
    }

    @Override
    public PlaylistEntity getFile(int id) {
        return playlistRepo.findById(id).get();
    }

    @Override
    public List<PlaylistEntity> getPlaylist() {
        return playlistRepo.findAll();
    }

    @Override
    public PlaylistEntity createPlayList(PlaylistEntity playlistEntity) {
        return playlistRepo.save(playlistEntity);
    }

    @Override
    public Optional<PlaylistEntity> findPlaylistById(int id) {
        return playlistRepo.findById(id);
    }

    @Override
    public void remove(int id) {
        playlistRepo.deleteById(id);
    }

    @Override
    public PlaylistEntity getId(int id) {
        return playlistRepo.getById(id);
    }

    @Override
    public PlaylistEntity update(MultipartFile file,PlaylistEntity playlistEntity) throws IOException {
        PlaylistEntity playlistEntity1 = new PlaylistEntity(playlistEntity.getId(),playlistEntity.getName(), file.getBytes(), playlistEntity.getUserId());
        return playlistRepo.save(playlistEntity1);
    }

}
