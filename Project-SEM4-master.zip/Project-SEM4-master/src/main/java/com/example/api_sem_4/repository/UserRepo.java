package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.SongEntity;
import com.example.api_sem_4.entity.UserEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

@Transactional
public interface UserRepo extends JpaRepository<UserEntity, Integer> {
    UserEntity findByUsername(String username);

    @Query("select s from UserEntity s where s.username like %:name%")
    Page<UserEntity> findSongByName(String name, Pageable pageable);

    @Modifying
    @Query("update UserEntity u set u.avatar = ?1 where u.id = ?2")
    void updateAvatar(byte[] avatar, Integer id);

    @Modifying
    @Query("update UserEntity u set u.username = ?1, u.dateofbirth=?2, u.address=?3, u.phone=?4, u.email=?5  where u.id = ?6")
    void updateProfile(String username, String dateofbirth, String address, String phone, String email, Integer id);

    @Query("select count(u) from UserEntity u")
    Long getCount();
}
