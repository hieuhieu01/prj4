package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.MvEntity;
import com.example.api_sem_4.repository.MvRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class MvServiceImpl implements MvService {
    @Autowired
    MvRepo mvRepo;

    @Override
    public List<MvEntity> getMv() {
        return mvRepo.findAll();
    }

    @Override
    public Optional<MvEntity> findMvById(int id) {
        return mvRepo.findById(id);
    }

    @Override
    public Page<MvEntity> getMvByName(String name, Pageable pageable) {
        return mvRepo.findMvByName(name, pageable);
    }

    @Override
    public MvEntity createMv(MultipartFile url,MultipartFile file, MvEntity mvEntity) throws IOException {
        MvEntity mvEntity1=new MvEntity(mvEntity.getName(), url.getBytes(), file.getBytes(), mvEntity.getDescription(),
                mvEntity.getLyrics(), mvEntity.getDuration(), mvEntity.getView(),mvEntity.getAuthor_id(),mvEntity.getGenre_id(),mvEntity.getSingers());
        return mvRepo.save(mvEntity1);
    }

    @Override
    public Page<MvEntity> findAll(Pageable pageable) {
        return mvRepo.findAll(pageable);
    }

    @Override
    public List<MvEntity> getAllMv(Pageable pageable) {
        return mvRepo.findAll(pageable).getContent();
    }

    @Override
    public int getTotalPage(Pageable pageable) {
        return mvRepo.findAll(pageable).getTotalPages();
    }

    @Override
    public void deleteMv(int id) {
        mvRepo.deleteById(id);
    }

    @Override
    public MvEntity getId(int id) {
        return mvRepo.getById(id);
    }

    @Override
    public MvEntity updateMv(MultipartFile url,MultipartFile file,MvEntity mvEntity) throws IOException {
        MvEntity mvEntity1=new MvEntity(mvEntity.getId(),mvEntity.getName(), url.getBytes(), file.getBytes(), mvEntity.getDescription(),
                mvEntity.getLyrics(), mvEntity.getDuration(), mvEntity.getView(),mvEntity.getAuthor_id(),mvEntity.getGenre_id(),mvEntity.getSingers());
        return mvRepo.save(mvEntity1);
    }

    @Override
    public List<MvEntity> getByName(String name, Pageable pageable) {
        return mvRepo.findByName(name, pageable);
    }

    @Override
    public int getTotalPageSearch(String name, Pageable pageable) {
        return mvRepo.findMvByName(name,pageable).getTotalPages();
    }

    @Override
    public Stream<MvEntity> getAllImage() {
        return mvRepo.findAll().stream();
    }

    @Override
    public Stream<MvEntity> getAllUrl() {
        return mvRepo.findAll().stream();
    }

    @Override
    public Long getCount() {
        return mvRepo.getCount();
    }

}
