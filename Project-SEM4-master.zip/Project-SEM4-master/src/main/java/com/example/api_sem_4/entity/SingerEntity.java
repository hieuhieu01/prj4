package com.example.api_sem_4.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.ValueGenerationType;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "singer")
public class SingerEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "yearOfBirth")
    private int yearOfBirth;

    @Column(name = "gender")
    private String gender;

    @Lob
    @Column(name = "image")
    private byte[] image;

    @Lob
    @Column(name = "avatar")
    private byte[] avatar;

    @Column(name = "biography", columnDefinition = "TEXT")
    private String biography;

    @JsonIgnore
    @ManyToMany(mappedBy = "singers")
    private List<SongEntity> songs;

    @JsonIgnore
    @ManyToMany(mappedBy = "singers")
    private List<MvEntity> mvs;

    public SingerEntity() {
    }

    public SingerEntity(String name, int yearOfBirth, String gender, byte[] image, byte[] avatar, String biography) {
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.gender = gender;
        this.image = image;
        this.avatar = avatar;
        this.biography = biography;
    }

    public SingerEntity(int id,String name, int yearOfBirth, String gender, byte[] image, byte[] avatar, String biography) {
        this.id = id;
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.gender = gender;
        this.image = image;
        this.avatar = avatar;
        this.biography = biography;
    }

    public SingerEntity(int id, String name, int yearOfBirth, String gender, byte[] image, byte[] avatar, String biography, List<SongEntity> songs, List<MvEntity> mvs) {
        this.id = id;
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.gender = gender;
        this.image = image;
        this.avatar = avatar;
        this.biography = biography;
        this.songs = songs;
        this.mvs = mvs;
    }

    public SingerEntity(String name, int yearOfBirth, String gender, byte[] image, byte[] avatar, String biography, List<SongEntity> songs, List<MvEntity> mvs) {
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.gender = gender;
        this.image = image;
        this.avatar = avatar;
        this.biography = biography;
        this.songs = songs;
        this.mvs = mvs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public byte[] getAvatar() {
        return avatar;
    }

    public void setAvatar(byte[] avatar) {
        this.avatar = avatar;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public List<SongEntity> getSongs() {
        return songs;
    }

    public void setSongs(List<SongEntity> songs) {
        this.songs = songs;
    }

    public List<MvEntity> getMvs() {
        return mvs;
    }

    public void setMvs(List<MvEntity> mvs) {
        this.mvs = mvs;
    }
}
