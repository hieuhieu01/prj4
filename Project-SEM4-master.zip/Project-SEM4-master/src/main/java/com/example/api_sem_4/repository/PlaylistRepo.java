package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.PlaylistEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlaylistRepo extends JpaRepository<PlaylistEntity, Integer> {
}
