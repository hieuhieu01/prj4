package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.SongPlayList;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SongPlaylistRepo extends JpaRepository<SongPlayList,Integer> {
}
