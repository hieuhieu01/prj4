package com.example.api_sem_4.sercice;

import com.example.api_sem_4.entity.AlbumEntity;
import com.example.api_sem_4.entity.AuthorEntity;
import com.example.api_sem_4.entity.GenreEntity;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface GenreService {
    List<GenreEntity> getGenre();

    GenreEntity createGenre(GenreEntity genreEntity);

    void deleteGenre(int id);
    int getTotalPage(Pageable pageable);
    List<GenreEntity> getAllGenre(Pageable pageable);

    GenreEntity getId(int id);
    GenreEntity updateGenre(GenreEntity genreEntity);
    List<GenreEntity> getByName(String name, Pageable pageable);
    int getTotalPageSearch(String name, Pageable pageable);

    Long getCount();
}
