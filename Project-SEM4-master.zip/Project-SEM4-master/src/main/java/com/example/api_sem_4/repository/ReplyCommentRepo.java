package com.example.api_sem_4.repository;

import com.example.api_sem_4.entity.ReplyCommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReplyCommentRepo extends JpaRepository<ReplyCommentEntity,Integer> {
}
