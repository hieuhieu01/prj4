package com.example.api_sem_4.controller;

import com.example.api_sem_4.entity.AuthorEntity;
import com.example.api_sem_4.entity.GenreEntity;
import com.example.api_sem_4.entity.MvEntity;
import com.example.api_sem_4.entity.SingerEntity;
import com.example.api_sem_4.sercice.AuthorService;
import com.example.api_sem_4.sercice.GenreService;
import com.example.api_sem_4.sercice.MvService;
import com.example.api_sem_4.sercice.SingerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Controller
public class MvController {
    @Autowired
    MvService mvService;
    @Autowired
    AuthorService authorService;
    @Autowired
    GenreService genreService;
    @Autowired
    SingerService singerService;

    @GetMapping("/mv")
    public String getAllMv(Model model){
        List<MvEntity> listMv = mvService.getMv();
        model.addAttribute("listMv",listMv);
        return "main/mv";
    }

    @GetMapping("/mv/{id}")
    public String detailMv(@PathVariable("id") int id, Model model){
        Optional<MvEntity> mvById = mvService.findMvById(id);
        mvById.ifPresent(mvs -> model.addAttribute("mvs", mvs));
        return "main/detail-mv";
    }

    @ModelAttribute("list_genre")
    public List<GenreEntity> listGenre(){
        return genreService.getGenre();
    }

    @ModelAttribute("list_author")
    public List<AuthorEntity> listAuthor(){
        return authorService.getAuthor();
    }

    @ModelAttribute("list_singer")
    public List<SingerEntity> listSinger(){
        return singerService.getSinger();
    }

    @ModelAttribute("list_mv")
    public List<MvEntity> listMv(){
        return mvService.getMv();
    }


    @GetMapping({"/add-mv"})
    public String addMv(Model model) {
        MvEntity mvEntity = new MvEntity();
        model.addAttribute("mvs",mvEntity);

        return "admin/add-mv";
    }

    @PostMapping("/add-mv")
    public String addMv(@RequestParam("urlmv") MultipartFile url,@RequestParam("images") MultipartFile file, Model model, MvEntity mvEntity) throws IOException {
        mvService.createMv(url,file,mvEntity);
        return "redirect:/table-mv";
    }

    @GetMapping({"/table-mv"})
    public String detail(Model model, @RequestParam("name") Optional<String> name, @RequestParam(value = "page", defaultValue = "0") int page, @RequestParam(value = "size", defaultValue = "10") int size) {
        List<MvEntity> mvlist;
        int totalPage;
        if (name.isPresent()) {
            mvlist = mvService.getByName(name.get(), PageRequest.of(page, size));
            totalPage  = mvService.getTotalPageSearch(name.get(),PageRequest.of(page, size));
            model.addAttribute("t",1);
            model.addAttribute("namesearch",name.get());
        } else {
            mvlist = mvService.getAllMv(PageRequest.of(page, size));
            totalPage  = mvService.getTotalPage(PageRequest.of(page, size));
        }
        model.addAttribute("totalPage", totalPage);
        model.addAttribute("size", size);
        model.addAttribute("page", page);
        model.addAttribute("mvlist",mvlist);

        return "admin/table-mv";
    }

    @GetMapping("/delete-mv/{id}")
    public String deleteMv(Model model, @PathVariable int id) {
        if (id != 0) {
            mvService.deleteMv(id);
        }
        return "redirect:/table-mv";
    }

    @GetMapping("/update-mv/{id}")
    public String updateMv(Model model,@PathVariable int id) {
        MvEntity mvEntity = mvService.getId(id);
        model.addAttribute("mvs", mvEntity);
        return "admin/update-mv";
    }

    @PostMapping("/update-mv")
    public String updateMv(@RequestParam("url") MultipartFile url,@RequestParam("images")MultipartFile file, Model model,MvEntity mvEntity) throws IOException {
        mvService.updateMv(url,file,mvEntity);
        return "redirect:/table-mv";
    }
}
