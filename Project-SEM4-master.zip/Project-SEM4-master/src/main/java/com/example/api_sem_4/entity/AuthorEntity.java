package com.example.api_sem_4.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "author")
public class AuthorEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "name")
    private String name;

    @JsonIgnore
    @OneToMany(mappedBy = "author", fetch = FetchType.LAZY)
    List<SongEntity> songs;

    @JsonIgnore
    @OneToMany(mappedBy = "author_mv", fetch = FetchType.LAZY)
    List<MvEntity> mv;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<SongEntity> getSongs() {
        return songs;
    }

    public void setSongs(List<SongEntity> songs) {
        this.songs = songs;
    }

    public List<MvEntity> getMv() {
        return mv;
    }

    public void setMv(List<MvEntity> mv) {
        this.mv = mv;
    }
}
